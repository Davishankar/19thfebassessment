package com.tavant.address.helper;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;
import org.springframework.web.multipart.MultipartFile;

import com.tavant.address.models.FileDB;
public class csvfieldreader {
  public static String TYPE = "text/csv";
  static String[] HEADERs = { "Id", "Title", "Description", "Published" };

  public static boolean hasCSVFormat(MultipartFile file) {

    if (!TYPE.equals(file.getContentType())) {
      return false;
    }

    return true;
  }

  public static List<FileDB> csvToTutorials(InputStream is) {
    try (BufferedReader fileReader = new BufferedReader(new InputStreamReader(is, "UTF-8"));
        CSVParser csvParser = new CSVParser(fileReader,
            CSVFormat.DEFAULT.withFirstRecordAsHeader().withIgnoreHeaderCase().withTrim());) {

      List<FileDB> filedbs = new ArrayList<FileDB>();

      Iterable<CSVRecord> csvRecords = csvParser.getRecords();

      for (CSVRecord csvRecord : csvRecords) {
    	  FileDB filedb = new FileDB(
    			  Integer.parseInt(csvRecord.get("Id")),
    			  csvRecord.get("HouseNumber"),
    			  csvRecord.get("HouseName"),
    			  csvRecord.get("POI"),
    			  csvRecord.get("Street"),
    			  csvRecord.get("SubSubLocality"),
    			  csvRecord.get("SubLocality"),
    			  csvRecord.get("Locality"),
    			  csvRecord.get("Village"),
    			  csvRecord.get("SubDistrict"),
    			  csvRecord.get("District"),
    			  csvRecord.get("City"),
    			  csvRecord.get("State"),
    			  csvRecord.get("Pincode"),
    			  csvRecord.get("FormattedAddress"),
    			  csvRecord.get("Eloc"),
    			  csvRecord.get("GeocodeLevel"),
    			  csvRecord.get("ConfidenceScore")
            );

    	  filedbs.add(filedb);
      }

      return filedbs;
    } catch (IOException e) {
      throw new RuntimeException("fail to parse CSV file: " + e.getMessage());
    }
  }

}