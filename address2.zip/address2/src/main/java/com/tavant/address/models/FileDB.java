package com.tavant.address.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="address")
public class FileDB {


	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	//@Column(name = "house_number")
	private String houseNumber;
	//@Column(name = "house_name")
	private String houseName;
	@Column(name = "poi")
	private String poi;
	@Column(name = "street")
	private String street;
	//@Column(name = "sub_sub_locality")
	private String subSubLocality;
	//@Column(name = "sub_locality")
	private String subLocality;
	@Column(name = "locality")
	private String locality;
	@Column(name = "village")
	private String village;
	//@Column(name = "sub_district")
	private String subDistrict;
	@Column(name = "district")
	private String district;
	@Column(name = "city")
	private String city;
	@Column(name = "state")
	private String state;
	@Column(name = "pincode")
	private String pincode;
	//@Column(name = "formatted_address")
	private String formattedAddress;
	//@Column(name = "e_loc")
	private String eLoc;
	//@Column(name = "geocode_level")
	private String geocodeLevel;
	//@Column(name = "confidence_score")
	private String confidenceScore;

  

  public FileDB() {

  }

  public FileDB(int id, String houseNumber, String houseName, String poi, String street, String subSubLocality, String subLocality, String locality, String village, String subDistrict, String district, String city, String state, String pincode, String formattedAddress, String eLoc, String geocodeLevel, String confidenceScore ) {
	  
	  this.id= id;
	  this.houseNumber= houseNumber;
	  this.houseName= houseName;
	  this.poi=poi;
	  this.street= street;
	  this.subSubLocality= subSubLocality;
	  this.subLocality= subLocality;
	  this.locality= locality;
	  this.village= village;
	  this.subDistrict=subDistrict;
	  this.district= district;
	  this.city=city;
	  this.state=state;
	  this.pincode=pincode;
	  this.formattedAddress= formattedAddress;
	  this.eLoc=eLoc;
	  this.geocodeLevel=geocodeLevel;
	  this.confidenceScore=confidenceScore;

  }

public Integer getId() {
	return id;
}



public void setId(Integer id) {
	this.id = id;
}



public String getHouseNumber() {
	return houseNumber;
}



public void setHouseNumber(String houseNumber) {
	this.houseNumber = houseNumber;
}



public String getHouseName() {
	return houseName;
}



public void setHouseName(String houseName) {
	this.houseName = houseName;
}



public String getPoi() {
	return poi;
}



public void setPoi(String poi) {
	this.poi = poi;
}



public String getStreet() {
	return street;
}



public void setStreet(String street) {
	this.street = street;
}



public String getSubSubLocality() {
	return subSubLocality;
}



public void setSubSubLocality(String subSubLocality) {
	this.subSubLocality = subSubLocality;
}



public String getSubLocality() {
	return subLocality;
}



public void setSubLocality(String subLocality) {
	this.subLocality = subLocality;
}



public String getLocality() {
	return locality;
}



public void setLocality(String locality) {
	this.locality = locality;
}



public String getVillage() {
	return village;
}



public void setVillage(String village) {
	this.village = village;
}



public String getSubDistrict() {
	return subDistrict;
}



public void setSubDistrict(String subDistrict) {
	this.subDistrict = subDistrict;
}



public String getDistrict() {
	return district;
}



public void setDistrict(String district) {
	this.district = district;
}



public String getCity() {
	return city;
}



public void setCity(String city) {
	this.city = city;
}



public String getState() {
	return state;
}



public void setState(String state) {
	this.state = state;
}



public String getPincode() {
	return pincode;
}



public void setPincode(String pincode) {
	this.pincode = pincode;
}



public String getFormattedAddress() {
	return formattedAddress;
}



public void setFormattedAddress(String formattedAddress) {
	this.formattedAddress = formattedAddress;
}



public String geteLoc() {
	return eLoc;
}



public void seteLoc(String eLoc) {
	this.eLoc = eLoc;
}



public String getGeocodeLevel() {
	return geocodeLevel;
}



public void setGeocodeLevel(String geocodeLevel) {
	this.geocodeLevel = geocodeLevel;
}

public String getConfidenceScore() {
	return confidenceScore;
}

public void setConfidenceScore(String confidenceScore) {
	this.confidenceScore = confidenceScore;
}

@Override
public String toString() {
  return "Address [id=" + id + ", house number=" + houseNumber + ", house name=" + houseName + ", poi=" + poi + ", street=" + street + ", sub sub locality=" + subSubLocality + ", sub locality=" + subLocality + ", locality=" + locality + ", village=" + village + ", sub District =" + subDistrict + ", district=" + district + ", city=" + city + ", state=" + state + ", pincode=" + pincode + ", formatted address=" + formattedAddress + ", eloc=" + eLoc + ", geocode level=" + geocodeLevel + ", confidence score=" + confidenceScore  + "]";
}
}

